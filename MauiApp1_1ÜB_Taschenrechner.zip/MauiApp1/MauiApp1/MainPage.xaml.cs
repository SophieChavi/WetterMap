﻿namespace MauiApp1;

public partial class MainPage : ContentPage
{
	int a = 0;
	int b = 0;
	int c = 0;
	bool first = false;
	string operation = "";

	public MainPage()
	{
		InitializeComponent();
	}

    private void Int_Btn_Clicked(object sender, EventArgs e)
    {
        Button button = (Button)sender;
		lbl_input.Text += button.Text;
    }

    private void Act_Btn_Clicked(object sender, EventArgs e)
    {
        Button button = (Button)sender;
        if (button.Text=="=")
		{
            if (first)
            {
                b = int.Parse(lbl_input.Text);
            }

            switch (operation)
			{
				case "+": c = a + b; break;
                case "-": c = a - b; break;
				default: c = int.Parse(lbl_input.Text); break;
            }
			
			a = c;
			first = true;
			lbl_output.Text = c.ToString();
		}
        else
        {
			if(first)
			{
				b = int.Parse(lbl_input.Text);
            }
			else
				a = int.Parse(lbl_input.Text);
			operation = button.Text;
			lbl_input.Text = "";
			first = true;
        }
    }
}

